#ifndef INSERTION_SORT_H
#define INSERTION_SORT_H

#include <stdint.h>
#include "../constants.h"

int insertion_sort(const char** data, uint* indices, uint indices_size);

#endif //INSERTION_SORT_H
